#!/bin/bash
java -Xmx1024m -jar TER.jar